package com.example.countryapi.viewModel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf

import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.countryapi.model.Country
import com.example.countryapi.network.ApiService
import kotlinx.coroutines.launch


class CountryViewModel: ViewModel() {
    val TAG = "CountryViewModel"
    var countryListResponse:List<Country> by mutableStateOf(listOf())
    var errorMessage: String by mutableStateOf("")

    fun getCountryList(){
        Log.v(TAG, "get country list")

        viewModelScope.launch{
            val apiService = ApiService.getInstance()
            try{
                val countryList = apiService.getCountries()
                countryListResponse = countryList
                Log.v(TAG, "api response: ${countryListResponse.size}")
            }
            catch(e:Exception){
                e.printStackTrace()
                errorMessage = e.message.toString()
                Log.v(TAG, "api error")
            }
        }
    }
}