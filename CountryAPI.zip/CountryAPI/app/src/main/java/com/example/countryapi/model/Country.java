
package com.example.countryapi.model;

import java.util.List;
import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Country {

    @com.squareup.moshi.Json(name = "name")
    private Name name;
    @com.squareup.moshi.Json(name = "capital")
    private List<String> capital;

    @com.squareup.moshi.Json(name = "region")
    private String region;

    @com.squareup.moshi.Json(name = "landlocked")
    private Boolean landlocked;

    @com.squareup.moshi.Json(name = "flag")
    private String flag;

//    @com.squareup.moshi.Json(name = "flags")
//    private Flags flags;

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }
    public List<String> getCapital() {
        return capital;
    }
    public String getRegion() {
        return region;
    }
    public Boolean getLandlocked() {
        return landlocked;
    }
    public String getFlag() {
        return flag;
    }

    //public Flags getFlags() { return flags; }


}

