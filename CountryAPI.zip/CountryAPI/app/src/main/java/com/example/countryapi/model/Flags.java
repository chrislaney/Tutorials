package com.example.countryapi.model;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Flags {

    @com.squareup.moshi.Json(name = "png")
    private String png;
    @com.squareup.moshi.Json(name = "svg")
    private String svg;

    public String getPng() {
        return png;
    }

    public void setPng(String png) {
        this.png = png;
    }

    public String getSvg() {
        return svg;
    }

    public void setSvg(String svg) {
        this.svg = svg;
    }

}