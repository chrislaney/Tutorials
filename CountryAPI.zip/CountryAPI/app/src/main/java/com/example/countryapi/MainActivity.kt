package com.example.countryapi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.countryapi.model.Country
import com.example.countryapi.model.Name
import com.example.countryapi.ui.theme.CountryAPITheme
import com.example.countryapi.view.CountryItem
import com.example.countryapi.viewModel.CountryViewModel

@coil.annotation.ExperimentalCoilApi
class MainActivity : ComponentActivity() {

    val countryViewModel by viewModels<CountryViewModel>() //added
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        countryViewModel.getCountryList()
        setContent {
            CountryAPITheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    CountryList(countryList = countryViewModel.countryListResponse)

                }
            }
        }
    }
}

@Composable
@coil.annotation.ExperimentalCoilApi
fun CountryList(countryList: List<Country>){
    LazyColumn{
        itemsIndexed(items = countryList){index, item ->
            CountryItem(country = item)
        }
    }
}
//@coil.annotation.ExperimentalCoilApi
//@Preview(showBackground = true)
//@Composable
//fun DefaultPreview() {
//    CountryAPITheme {
//        val country= Country(listOf("Budapest"), "imageurlhere", true, Name("Hungary"),"Europe")
//        CountryItem(country = country)
//    }
//}