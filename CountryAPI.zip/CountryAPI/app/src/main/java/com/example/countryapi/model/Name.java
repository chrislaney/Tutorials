
package com.example.countryapi.model;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Name {
    @com.squareup.moshi.Json(name = "common")
    private String common;
    public String getCommon() {
        return common;
    }
}
