package com.example.countryapi.network

import com.example.countryapi.model.Country
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.converter.moshi.MoshiConverterFactory



interface ApiService {
    @GET("/v3.1/all") //link to specific get (what part of website you want to GET from)
    suspend fun getCountries() : List<Country>

    companion object{
        var apiService:ApiService? = null
        fun getInstance() : ApiService{
            if(apiService == null){
                apiService = Retrofit.Builder()
                    .baseUrl("https://restcountries.com")//general link to site
                    .addConverterFactory(MoshiConverterFactory.create()) // Gson converter factory but I did use moshi to create kt data classes... could this cause problems?
                    .build().create(ApiService::class.java)
            }
            return apiService!!
        }
    }
}